Nom du Projet : Handle

Auteur : Elian WOLF, Augustin BIAR, sammy RABHINE

État du projet : Phase Final

Description : Handle est un logiciel ayant pour but de facilité l’orientation des personnes atteintes de troubles aux poignets vers des spécialistes (ostéopathe, chiropracteur, médecin généraliste…)
	      en réalisant un diagnostic des différents symptômes et causes de ce trouble tout en leurs donnant des conseils de premiers soins si besoin est.

Mise en place et utilisation rapide : 1) Lancer la fenetre de connexion
                                      2) se connecter ou s'inscrire
                                      3) se rendre dans l'onglet examen 
                                      4) Une fois l'examen fini se rendre dans l'onglet diagnostique pour plus de detail.

Rapport de bug : - Problème d'affichage dans l'onglet diagnostique suite à plusieurs examen effectuer.				      